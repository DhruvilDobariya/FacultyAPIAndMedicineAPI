import { Faculty } from './faculty';

describe('Faculty', () => {
  it('should create an instance', () => {
    expect(new Faculty()).toBeTruthy();
  });
});
