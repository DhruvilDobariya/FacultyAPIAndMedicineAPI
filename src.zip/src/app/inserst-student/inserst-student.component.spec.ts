import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InserstStudentComponent } from './inserst-student.component';

describe('InserstStudentComponent', () => {
  let component: InserstStudentComponent;
  let fixture: ComponentFixture<InserstStudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InserstStudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InserstStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
