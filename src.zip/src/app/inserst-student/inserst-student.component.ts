import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inserst-student',
  templateUrl: './inserst-student.component.html',
  styleUrls: ['./inserst-student.component.css']
})
export class InserstStudentComponent implements OnInit {

  title = "Dhruvil Dobariya"; // This is interpolation example. 
  isDisable = true; // This is proparty binding example.
  student : string[] = ["Dhruvil", "Dobariya"];
  input = "";
  a = false;
  position : number = -1;
  isEdit : boolean = false;

  constructor() { }

  ngOnInit(): void {
  }
  key(){  // This is event binding example.
    if(this.input.length != 0){
      this.isDisable = false;
    }
  }
  insert(){
    this.student.push(this.input);
    this.input = "";
    alert("Student added successfully");
  }
  delete(n:any){
    this.a = confirm("Are you sure, you want to delete "+ n +"?");
    if(this.a == true){
      this.student.splice(this.student.indexOf(n),1);
    }
    // If we want to delete Dhruvil.
    //Then this.student.splice(this.student.indexOf(0),1) = "Dhruvil".
    // And this.student = ["Dobariya"]. 
    // Here splice function is use to romove element on particuler index.
    // arrayName.splice(arg1,arg2).
    // Here arg1 = index of array which we want start to remove element.
    // Here arg2 = number of element which we want to remove.
  }
  edit(name:string){
    this.position = this.student.indexOf(name);
    this.input = name;
    this.isEdit = true;
  }
  take(){
    this.student[this.position] = this.input;
    this.input = "";
    this.isEdit = false;
    alert("Student updeted successfully.");
  }
}
