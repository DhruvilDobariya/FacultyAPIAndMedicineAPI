import { DetailFacultyComponent } from './detail-faculty/detail-faculty.component';
import { FacultiesComponent } from './faculties/faculties.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { InserstStudentComponent } from './inserst-student/inserst-student.component';
import { StudentComponent } from './student/student.component';
import { InsertEditFacultyComponent } from './insert-edit-faculty/insert-edit-faculty.component';
const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'about',
    component: AboutComponent
  },
  {
    path: 'inserst-student',
    component: InserstStudentComponent
  },
  {
    path: 'student',
    component: StudentComponent
  },
  {
    path: 'faculties',
    component: FacultiesComponent
  },
  {
    path: 'faculty/add',
    component: InsertEditFacultyComponent
  },
  {
    path: 'faculty/edit/:id',
    component: InsertEditFacultyComponent
  },
  {
    path: 'faculty/:id',
    component: DetailFacultyComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
