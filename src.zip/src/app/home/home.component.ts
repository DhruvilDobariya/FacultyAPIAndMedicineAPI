import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  title = "Dhruvil Dobariya"; // This is interpolation example. 
  isDisable = true; // This is proparty binding example.

  constructor() { }

  ngOnInit(): void {
  }
  key(){  // This is event binding example.
    this.isDisable = false;
  }
}
