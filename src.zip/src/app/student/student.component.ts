import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  title = "Dhruvil Dobariya"; // This is interpolation example. 
  isDisable = true; // This is proparty binding example.
  student : {rollNo : number,name : string,gender : string,image : any [],dateOfBirth : string} [] = [];
  inputName = "";
  inputRollNo = "";
  inputGender = "Male";
  a = false;
  position : number = -1;
  isEdit : boolean = false;
  myImage: any [] = [];
  inputDateOfBirth : string = "";

  constructor() { }

  ngOnInit(): void {
  }
  key(){  // This is event binding example.
    if(this.inputName.length != 0){
      this.isDisable = false;
    }
  }
  insert(){
    let temp = {
      rollNo: parseInt(this.inputRollNo), 
      name: this.inputName,
      gender: this.inputGender,
      image : this.myImage,
      dateOfBirth : this.inputDateOfBirth
    }
    this.student.push(temp);
    this.inputName = "";
    this.inputRollNo = "";
    this.inputGender = "Male"
    this.inputDateOfBirth = "";
    alert("Student added successfully");
  }
  delete(s:{rollNo : number, name : string, gender : string, image : any [], dateOfBirth : string}){
    this.a = confirm("Are you sure, you want to delete "+ s.name +"?");
    if(this.a == true){
      this.student.splice(this.student.indexOf(s),1);
    }
  }
  edit(s: {rollNo : number, name : string, gender : string, image : any [], dateOfBirth : string}){
    this.position = this.student.indexOf(s);
    this.inputName = s.name;
    this.inputRollNo = s.rollNo + "";
    this.inputGender = s.gender;
    this.inputDateOfBirth = s.dateOfBirth;
    this.isEdit = true;
  }
  take(){
    this.student[this.position] = {rollNo: parseInt(this.inputRollNo),name: this.inputName,gender: this.inputGender,image : this.myImage,dateOfBirth : this.inputDateOfBirth};
    this.inputName = "";
    this.inputRollNo = "";
    this.inputGender = "Male";
    this.inputDateOfBirth = "";
    this.isEdit = false;
    alert("Student updeted successfully.");
  }
  image(e: any){
    var reader = new FileReader();
    reader.onload = (f : any)=>{
      this.myImage = f.target.result;
    }
    reader.readAsDataURL(e.target.files[0]);
  }
}
