import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { InserstStudentComponent } from './inserst-student/inserst-student.component';
import { FormsModule } from '@angular/forms';
import { StudentComponent } from './student/student.component';
import { FacultiesComponent } from './faculties/faculties.component';
import {HttpClientModule} from '@angular/common/http';
import { DetailFacultyComponent } from './detail-faculty/detail-faculty.component';
import { InsertEditFacultyComponent } from './insert-edit-faculty/insert-edit-faculty.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    AboutComponent,
    HomeComponent,
    InserstStudentComponent,
    StudentComponent,
    FacultiesComponent,
    DetailFacultyComponent,
    InsertEditFacultyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
